// for better vision use iPad orientation landscape left or right.

import SwiftUI

struct ContentView: View {
    @State private var font: Font?

    var body: some View {
        NavigationStack {
            ZStack {
                Image("mainpage")
                    .resizable()
                    .ignoresSafeArea()

                HStack {
                    VStack {
                        Spacer()
                        HStack {
                            ZStack {
                                NavigationLink {
                                    level1()
                                } label: {
                                    ZStack {
                                        Image("buttonStart")
                                            .resizable()
                                            .frame(width: 450, height: 150)

                                        Text("Start")
                                            .foregroundColor(.black)
                                            .font(font ?? Font.system(size: 50)) // Use custom font if available, else use system font
                                    }
                                }
                            }
                        }
                        Spacer()
                    }
                }
                .task {
                    getFont()
                }
            }
        }
    }

    func getFont() {
        if let cfURL = Bundle.main.url(forResource: "Attack Of Monster", withExtension: "ttf") as CFURL? {
            CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
            if let uiFont = UIFont(name: "Attack Of Monster", size: 50) {
                font = Font(uiFont)
            } else {
                print("Unable to create UIFont.")
            }
        } else {
            print("Font file not found.")
        }
    }
}
