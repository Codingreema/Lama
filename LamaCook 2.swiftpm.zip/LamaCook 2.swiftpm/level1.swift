
// Make a better vision on iPad orientation landscape left or right.

import SwiftUI
import SpriteKit
import AVFoundation

// level 1 - game cook 
struct level1: View {

    var body: some View {
        ZStack {
            SpriteView(scene: GameScenes())
                .ignoresSafeArea()
           
        }
    }
}
#Preview {
    level1()
}
