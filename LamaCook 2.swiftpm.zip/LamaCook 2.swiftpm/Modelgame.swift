// here are the game's elements and move for ingredinats
// for better vision use iPad orientation landscape left or right.


import Foundation
import SpriteKit
// class for game elements
class GameScenes: SKScene {
    var blackPepper: SKSpriteNode!
    var Pot: SKSpriteNode!
    var dateFruit: SKSpriteNode!
    var hotWater: SKSpriteNode!
    var cup: SKSpriteNode!
    var whaetFlour: SKSpriteNode!
    var wheal: SKSpriteNode!
    var whisk: SKSpriteNode!
    var spoon: SKSpriteNode!
    var Mahala: SKSpriteNode!
    var waterPot: SKSpriteNode!
    var buttonKey: SKSpriteNode!
    var FireGas: SKSpriteNode!
    var touchStartPosition: CGPoint?
    var audioButton: SKSpriteNode!
    var noAudioButton: SKSpriteNode!
    var Handinfo: SKSpriteNode!
    var MahalaCook: SKSpriteNode!
    var DoneMahala: SKSpriteNode!
    
    var isAudioEnabled: Bool = true
    var isStirring: Bool = false
    var dateFruitStuck: Bool = false
    var cupIsEmpty: Bool = false
    
    override func didMove(to view: SKView) {
        // elements (ingredinats)
        
        // background game
        setupBackground()

        // mahala
        setupPot()
   
        // water pot
        setupWaterPot()
        
        
        // pot normal
        setupMahala()
       
        // cup wheal
        setupCup()
        
        // wheal flour
        setupWhaetFlour()
        
        // hot water
        setupHotWater()
        
        // after adding wheal flour
        setupWheal()
        
        // black pepper
        setupBlackPepper()
        
        // date fruit
        setupDate()
        
        // our whisk
        setupWhisk()
        
        // key to open the gas
        setupKey()
        
        // gas button
        setupFireGas()
        
        // rain audio
        startBackgroundMusic()
        
        // hand tutorial
        setupHand()
        
        setupDoneMahala()
    }
// all elements are needed for the game
    
    
    func setupBackground() {
        let texture = SKTexture(imageNamed: "GameBK")
        
        let background = SKSpriteNode(texture: texture)
        
        background.size = CGSize(width: size.width, height: size.height)
        
        background.size = self.size
        background.scale(to: self.size)
        
        background.position = CGPoint(x: size.width / 2, y: size.height / 2)
        
        addChild(background)
    }
    func setupDoneMahala() {
        let texture = SKTexture(imageNamed: "MahalaCook")
        
        DoneMahala = SKSpriteNode(texture: texture)  // Make sure this is the class variable
        DoneMahala.size = CGSize(width: size.width, height: size.height)
        DoneMahala.position = CGPoint(x: size.width / 2, y: size.height / 2)
        DoneMahala.isHidden = true  // Start hidden
        addChild(DoneMahala)
    }

   
    
    func setupDate() {
        dateFruit = SKSpriteNode(imageNamed: "DateFruit")
        
        let dateSize = CGSize(width: size.width / 5, height: size.height / 9)
        dateFruit.size = dateSize
        
        dateFruit.position = CGPoint(x: size.width / 1.5, y: size.height / 2.2)
        
        addChild(dateFruit)
    }

    func setupHand() {
        Handinfo = SKSpriteNode(imageNamed: "Handinfo")
        
        let HandinfoSize = CGSize(width: size.width / 7, height: size.height / 7)
        Handinfo.size = HandinfoSize
        
        Handinfo.position = CGPoint(x: size.width / 1.16, y: size.height / 5.8)
        
        addChild(Handinfo)
    }
    
    func setupKey() {
        buttonKey = SKSpriteNode(imageNamed: "Key")
        
        let buttonKeySize = CGSize(width: size.width / 22, height: size.height / 25)
        buttonKey.size = buttonKeySize
        
        buttonKey.position = CGPoint(x: size.width / 1.3, y: size.height / 11)
        
        addChild(buttonKey)
        
    }
    func setupFireGas() {
        FireGas = SKSpriteNode(imageNamed: "FireGas")
        
        let FireGasSize = CGSize(width: size.width / 5, height: size.height / 15)
        
        FireGas.size = FireGasSize
        
        FireGas.position = CGPoint(x: size.width / 1.55, y: size.height / 8.5)
        
        FireGas.isHidden = true
        
        addChild(FireGas)
    }


    func startBackgroundMusic() {
        if let musicURL = Bundle.main.url(forResource: "RainAudio", withExtension: "mp3") {
            let playSoundAction = SKAction.playSoundFileNamed(musicURL.lastPathComponent, waitForCompletion: true)
            let repeatForeverAction = SKAction.repeatForever(playSoundAction)
            run(repeatForeverAction, withKey: "backgroundMusic")
        } else {
            print("No audio file found")
            // Continue without audio
        }
    }


    func setupHotWater() {
        hotWater = SKSpriteNode(imageNamed: "Hot water")
        
        let hotWaterSize = CGSize(width: size.width / 7, height: size.height / 5)
        hotWater.size = hotWaterSize
        
        hotWater.position = CGPoint(x: size.width / 2.2, y: size.height / 2)
        
        addChild(hotWater)
    }
    func setupCup() {
        cup = SKSpriteNode(imageNamed: "cup")
        
        let cupSize = CGSize(width: size.width / 9, height: size.height / 7)
        cup.size = cupSize
        
        cup.position = CGPoint(x: size.width / 4, y: size.height / 2.2)
        
        addChild(cup)
    }
    func setupWheal() {
        wheal = SKSpriteNode(imageNamed: "wheal")
        
        let whealSize = CGSize(width: size.width / 6, height: size.height / 7)
        wheal.size = whealSize
        
        wheal.position = CGPoint(x: size.width / 1.6, y: size.height / 4.5)
        
        wheal.isHidden = true
        addChild(wheal)
    }
    
    func setupBlackPepper() {
        blackPepper = SKSpriteNode(imageNamed: "Black pepper")
        
        let blackPepperSize = CGSize(width: size.width / 9, height: size.height / 7)
        blackPepper.size = blackPepperSize
        
        blackPepper.position = CGPoint(x: size.width / 10, y: size.height / 9)
        
        addChild(blackPepper)
    }
    
    
    func setupWhaetFlour() {
        whaetFlour = SKSpriteNode(imageNamed: "whole whaet flour")
        
        let whaetFlourSize = CGSize(width: size.width / 6, height: size.height / 4)
        whaetFlour.size = whaetFlourSize
        
        whaetFlour.position = CGPoint(x: size.width / 9, y: size.height / 2)
        
        addChild(whaetFlour)
    }
    func setupWhisk() {
        whisk = SKSpriteNode(imageNamed: "Whisk")
        
        let whiskSize = CGSize(width: size.width / 10, height: size.height / 6)
        whisk.size = whiskSize
        
        whisk.position = CGPoint(x: size.width / 1.2, y: size.height / 2.3)
        
        addChild(whisk)
    }
    
    func setupPot() {
        Pot = SKSpriteNode(imageNamed: "Mahala")
        
        let PotSize = CGSize(width: size.width / 3, height: size.height / 5)
        Pot.size = PotSize
        
        Pot.position = CGPoint(x: size.width / 1.43, y: size.height / 5)
        
        addChild(Pot)
        
        
    }
    func setupMahala() {
        Mahala = SKSpriteNode(imageNamed: "pot")
        
        let MahalaSize = CGSize(width: size.width / 3, height: size.height / 5)
        Mahala.size = MahalaSize
        
        Mahala.position = CGPoint(x: size.width / 1.43, y: size.height / 5)
        
        addChild(Mahala)
    }
    func setupWaterPot() {
        waterPot = SKSpriteNode(imageNamed: "WaterPot")
        
        let waterPotSize = CGSize(width: size.width / 3, height: size.height / 5)
        waterPot.size = waterPotSize
        
        waterPot.position = CGPoint(x: size.width / 1.43, y: size.height / 5)
        
        addChild(waterPot)
    }
    func cupsfull(approaching: Bool) {
        let rotationAngle: CGFloat = approaching ? 130.0 : 0.0
        let rotateAction = SKAction.rotate(toAngle: CGFloat(GLKMathDegreesToRadians(Float(rotationAngle))), duration: 0.2)
        cup.run(rotateAction)
        
        if approaching {
            let cupImage = SKTexture(imageNamed: "cupEmpty")
            cup.texture = cupImage
        }
        wheal.isHidden = cupIsEmpty && cup.frame.intersects(Pot.frame)
    }
    
    func cupsEmty() {
        let cupImage = SKTexture(imageNamed: "cupEmpty")
        cup.texture = cupImage
    }
 // hand moves tutorial to each elements (ingredinats)
    func moveHandToDateFruit() {
        let newPosition = CGPoint(x: size.width / 1.4, y: size.height / 1.8)
        let moveAction = SKAction.move(to: newPosition, duration: 0.5)
        Handinfo.run(moveAction)
    }

    func moveHandToHotWater() {
        let newPosition = CGPoint(x: size.width / 1.8, y: size.height / 1.7)
        let moveAction = SKAction.move(to: newPosition, duration: 0.5)
        Handinfo.run(moveAction)
    }

    func moveHandToCup() {
        let newPosition = CGPoint(x: size.width / 3, y: size.height / 1.8)
        let moveAction = SKAction.move(to: newPosition, duration: 0.5)
        Handinfo.run(moveAction)
    }
    func moveHandToWhisk() {
        let newPosition = CGPoint(x: size.width / 1.1, y: size.height / 1.8)
        let moveAction = SKAction.move(to: newPosition, duration: 0.5)
        Handinfo.run(moveAction)
    }


    
    // here the moves to start cooking!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchStartPosition = touches.first?.location(in: self)
        
        
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        touchStartPosition = location
        

        // If i touch the key, the audio play!
        if buttonKey.contains(location) {
            
            let playSoundAction = SKAction.playSoundFileNamed("GasAudio.mp3", waitForCompletion: false)
            buttonKey.run(playSoundAction)
            
            let showFireGasAction = SKAction.run { [weak self] in
                self?.FireGas.isHidden = false
            }
            let sequenceAction = SKAction.sequence([  showFireGasAction])
            buttonKey.run(sequenceAction, withKey: "ShowFireGas")
        }
        
        // hand tutorial to teach you where to start.
        if buttonKey.contains(location) {
              Handinfo.position = dateFruit.position
          }
        if buttonKey.contains(location) {
              moveHandToDateFruit()
          }
        
    }

    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first, let startPosition = touchStartPosition else { return }
        let currentPosition = touch.location(in: self)
        let deltaX = currentPosition.x - startPosition.x
        let deltaY = currentPosition.y - startPosition.y
      
        // to move the cup
        if cup.frame.contains(startPosition) {
            cup.position.x += deltaX
            cup.position.y += deltaY
            
            // if cup reach the Mahala pot, it will add the wheal on the pot.
            if cup.frame.intersects(Mahala.frame) {
                let delayactions = SKAction.wait(forDuration: 0.5)
                let showWhealPot = SKAction.run {
                    self.wheal.isHidden = false
                
                }
                let squencee = SKAction.sequence([delayactions, showWhealPot])
                self.run(squencee)
            }
        // moves of the black pepper
        } else if blackPepper.frame.contains(startPosition) {
            blackPepper.position.x += deltaX
            blackPepper.position.y += deltaY
            
            let rotationAngle: CGFloat = deltaX * 0.02
            let rotateAction = SKAction.rotate(byAngle: rotationAngle, duration: 0.1)
            blackPepper.run(rotateAction)
            
            // move the date fruit to the pot!
        } else if dateFruit.frame.contains(startPosition) {
            dateFruit.position.x += deltaX
            dateFruit.position.y += deltaY
            
            if dateFruitStuck {
                
            }
            
            // see if the pot is there the date fruit is stuck
            if dateFruit.frame.intersects(Pot.frame) {
                dateFruitStuck = true
            } else {
                dateFruitStuck = false
            }
  
            // see if the hot water is rotate the waterPot will appear
        } else if hotWater.frame.contains(startPosition) {
            hotWater.position.x += deltaX
            hotWater.position.y += deltaY
            
            let rotationAngle: CGFloat = deltaX * 0.02
            let rotateAction = SKAction.rotate(byAngle: rotationAngle, duration: 0.1)
            hotWater.run(rotateAction)
        }
        
        if hotWater.frame.intersects(Pot.frame) {
            let delayaction = SKAction.wait(forDuration: 0.5)
            let showWaterPot = SKAction.run {
                self.Mahala.isHidden = true
                self.waterPot.isHidden = false
                self.Pot.isHidden = true
                self.dateFruit.isHidden = false
            }
            let squence = SKAction.sequence([delayaction, showWaterPot])
            self.run(squence)
        }
        // if i move the whisk to the Pot, the Pot (mahala) appear after 1 second
        if whisk.frame.contains(currentPosition) {
            isStirring = true
            
            whisk.position.x += deltaX
            whisk.position.y += deltaY
            
            if whisk.frame.intersects(Pot.frame) {
                let delayAction =  SKAction.wait(forDuration: 1.0)
                let showMahalaAction = SKAction.run {
                    self.waterPot.isHidden = true
                    self.dateFruit.isHidden = true
                    self.Mahala.isHidden = true
                    self.Pot.isHidden = false

                }
                let sequence = SKAction.sequence([delayAction, showMahalaAction])
                self.run(sequence)
            }
            
        } else {
            isStirring = false
        }
        

        touchStartPosition = currentPosition
    }
    
    
    
    // end the touches
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else { return }
            let location = touch.location(in: self)
            touchStartPosition = nil

           // press the key, audio FireGas is on
            if buttonKey.contains(location) {
                buttonKey.removeAction(forKey: "ShowFireGas")
            }
           
        touchStartPosition = nil
        
        if cup.frame.intersects(Pot.frame) {
            
            cupsfull(approaching: true)
           
            if whisk.frame.intersects(Pot.frame) {
                
                let delayAction = SKAction.wait(forDuration: 1.0)
                let showMahalaAction = SKAction.run {
                    self.Mahala.isHidden = true
                    self.dateFruit.isHidden = true
                    self.waterPot.isHidden = true
                    self.Pot.isHidden = false
                    self.DoneMahala.isHidden = false

                   }
                let sequence = SKAction.sequence([delayAction, showMahalaAction])
                self.run(sequence)
            }
            
        } else {
            cupsfull(approaching: false)
        }
        // adding the wheal if cup is close to the Mahala pot
        if cup.frame.intersects(Mahala.frame) {
            let Delayactions = SKAction.wait(forDuration: 0.5)
            let StartRuns = SKAction.run {
                self.wheal.isHidden = false
                
            }
        }
        if whisk.frame.contains(location) {
              let wait = SKAction.wait(forDuration: 2)
              let showDoneMahalaAction = SKAction.run { [weak self] in
                  self?.DoneMahala.isHidden = false
              }
              let sequence = SKAction.sequence([wait, showDoneMahalaAction])
              run(sequence)
          }

       // the cup empty appear if the cup rotate
        cupIsEmpty = cup.texture == SKTexture(imageNamed: "cupEmpty")
        wheal.isHidden = !(cupIsEmpty && cup.frame.intersects(Pot.frame))
     
        // check if the date Fruit is in the pot, the hand move to the next ingredinats
        if dateFruit.frame.contains(location) {

            moveHandToHotWater()
            
            // check if the hotWater is in the pot, the hand move to the next ingredinats

           } else if hotWater.frame.contains(location) {

            moveHandToCup()
           } else if cup.frame.contains(location) {

            moveHandToWhisk()
               
            // check if the whisk is in the pot, the hand move to the next ingredinats
           } else if whisk.frame.contains(location) {
              
               // hide the hand after done the cook
            Handinfo.isHidden = true
           } else if Pot.frame.contains(location)  {

              }
       
        
    }
}
