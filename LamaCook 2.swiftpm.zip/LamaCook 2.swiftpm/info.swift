
// Make a better vision on iPad orientation landscape left or right.

import SwiftUI

struct info: View {
    @State private var font: Font?
    
    var body: some View {
            ZStack {
                Image("MahalaCook")
                    .resizable()
                    .ignoresSafeArea()
                
            }
        }
    }
#Preview {
    info()
        
}
